In A Station Of The Metro

the apparition of these faces in the crowd
petals on a wet black bough
