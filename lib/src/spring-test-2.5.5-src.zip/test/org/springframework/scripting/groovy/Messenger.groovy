package org.springframework.scripting.groovy;

import org.springframework.scripting.ConfigurableMessenger

class GroovyMessenger implements ConfigurableMessenger {

	def String message;
}
