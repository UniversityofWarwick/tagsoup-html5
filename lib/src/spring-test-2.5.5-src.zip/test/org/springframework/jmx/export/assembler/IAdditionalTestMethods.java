
package org.springframework.jmx.export.assembler;

/**
 * @author Rob Harrop
 */
public interface IAdditionalTestMethods {

	String getNickName();

	void setNickName(String nickName);
	
}
